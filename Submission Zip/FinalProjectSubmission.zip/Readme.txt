- Link to repository with all the code - https://github.com/JohnWesleyK/CSU22012-DSA-Group-Project

- Group members list and summary of contributions of each member in the team
    Honglin Li - CSB - 19315272 - lih4@tcd.ie - Github Username - DesLeeHL
        - Did Part 1 of the project.
        - Assisted Hiroki with Part 2.
        - Assisted Hiroki and Masanari with git and github.
        - Worked on his part in the Desgin Document.
        - Created Discord server for communication.

    Masanari Doi - CSB - 19313167 - doim@tcd.ie - Github Username - dodonga2211
        - Did Part 2 of the project.
        - Worked on his part in the Desgin Document.

    John Kommala - ICS - 19303445 - kommalaj@tcd.ie - Github Username - JohnWesleyK
        - Set up a github repository for the project.
        - Did Part 3 of the project.
        - Assisted Hiroki and Masanari with git and github.
        - Assisted Hiroki with Part 4.
        - Assisted Desmond with Part 1.
        - Worked on his part in the Desgin Document.
        - Made the demo video.
    
    Hiroki Kumagai - CSB - 19312623 - kumagaih@tcd.ie - Github Username - kumachan96
        - Did Part 4 of the project.
        - Worked on his part in the Desgin Document.
